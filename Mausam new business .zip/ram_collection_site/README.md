# Ram.collection website

A responsive, premium-style storefront starter for Ram.collection.

## Preview locally
Open `index.html` in a modern browser. Product filtering and the demo shopping bag work locally.

## Publish for free with Netlify
1. Visit https://app.netlify.com/drop and sign in or create an account.
2. Unzip `ram-collection-website.zip` on your computer.
3. Drag the unzipped `ram_collection_site` folder (the folder containing `index.html`) onto Netlify Drop.
4. Netlify will provide a public `*.netlify.app` address. You can change the site name in Site configuration.
5. To use your own domain, add it under Domain management and follow Netlify's DNS instructions.

## Before accepting real orders
- Replace the sample products, photos, prices, product descriptions and policies with your actual catalogue.
- Update the contact email and social links.
- Connect a real checkout/payment provider (for example, a hosted Shopify store or a payment gateway). The current checkout is deliberately a demo and does not collect payment or submit orders.
- Add shipping, returns, privacy and terms pages, and verify applicable business/tax requirements.
- Test the site on mobile and desktop.

This is a static storefront prototype. Cart contents are stored in the visitor's browser using localStorage. Newsletter signup is a visual demo and does not submit addresses to a mailing list.
